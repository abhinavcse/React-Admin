import React, { Component } from 'react';
export default class Footer extends Component {
    render() {
        return (
            <div>
                This is Footer
            </div>
        );
    }
}

